<!DOCTYPE html>
<html>
<head>
  <title>Successful!</title>
<style>
body {
  background-image: url("BG3.jpg");
  background-position: center;
  background-size: 100%;
}
div {
  border: 1px solid black;
  background-color: white;
  opacity: 50%;
  padding: auto;
  margin: auto;
}

h1 {
  text-align: center;
  text-transform: uppercase;
  color: black;
}

</style>
</head>
<body>

<div>
  <h1>Payment Successful!</h1>
  
</div>
<button class="btn"><a href="index.php">Home</button>
</body>
</html>