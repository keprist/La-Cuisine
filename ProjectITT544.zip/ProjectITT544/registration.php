<?php
require_once('config.php');
?>
<!DOCTYPE html>
<html>
<head>
	<title>User Registration | PHP</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">

	<style>
         body {
            padding-top: 40px;
            padding-bottom: 40px;
            background-image: url("BG4.jpg");
            background-position: cover;
         }
    </style>

</head>
<body>

<div>
	<?php
	if (isset($_POST['create'])) {
		$Name 			= $_POST['Name'];
		$Address 		= $_POST['Address'];
		$Email 			= $_POST['Email'];
		$phonenumber 	= $_POST['phonenumber'];
		$password 		= $_POST['password'];

		$sql = "INSERT INTO users (Name, Address, Email, phonenumber, password ) VALUES (?,?,?,?,?)";
		$stmtinsert = $db->prepare($sql);
		$result = $stmtinsert-> execute ([$Name, $Address, $Email, $phonenumber, $password]);

		if ($result) {
			echo 'Saved.';
		}
		else{
			echo 'There were errors while saving the data.';
		}
	}
	?>
</div>

	<div>
		
		<form action="Registration.php" method="post">
			<div class="container">
				<div align = "center">
					<div style = "background-image: banner.jpg; padding:3px;"><b></div>
				<div class="row">
					<div class="col-sm-3">

					<h1>Registration</h1>
					<p>Fill up the form with correct value.</p>
					<hr class="mb-3">

					<label for="Name"><b>Name</b></label>
					<input class="form-control" type="text" id="Name" name="Name" required>

					<label for="Address"><b>Address</b></label>
					<input class="form-control" type="text" id="Address" name="Address" required>

					<label for="Email"><b>Email Address</b></label>
					<input class="form-control" type="Email" id="Email" name="Email" required>

					<label for="phonenumber"><b>Phone Number</b></label>
					<input class="form-control" type="text" id="phonenumber" name="phonenumber" required>

					<label for="password"><b>Password</b></label>
					<input class="form-control" type="password" id="password" name="password" required>

					<hr class="mb-3">
					<input class="btn btn-primary" type="submit" id="register" name="create" value="Sign Up">

					<hr class="mb-3">
					Already have account? <a href="login.php" style="text-decoration: none; font-family:'Play', sans-serif; color: yellow;">&nbsp;Log In</a>
					</div>
				</div>
				</div>
			</div>
		</form>

	</div>
</body>
</html>