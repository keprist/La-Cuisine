<!DOCTYPE html>
<html>
<head>
	<title>login form</title>

	<style>
         body {
            padding-top: 40px;
            padding-bottom: 40px;
            background-image: url("BG4.jpg");
            background-position: cover;
         }
    </style>

</head>
<body>

<form action="login.php" method="post">
			<div class="container">
				<div align = "center">
					<div style = padding:3px;"><b></div>
				<div class="row">
					<div class="col-sm-3">

					<h1>Reset Password</h1>
					<hr class="mb-3">
<div class="reset">
		<form>

			<input type="password" placeholder="Old password" /><br /><br />

			<input type="password" placeholder="New password" /><br /><br />

			<input type="password" placeholder="Confirm new password" /><br /><br />

			<input type="button" value="Save" onclick="myFunction()"/><br /><br />
			<a href="login.php" style="text-decoration: none;">Go back to Home Page</a><br /><br />
			<div id="msg">Your password changed successfully!!!</div>

			<script>
				function myFunction(){
					var x = document.getElementById("msg");
					x.className = "show";
					setTimeout(function(){ x.className = x.className.replace("show", ""); }, 3000);
				}
			</script>
		</form>
	</div>

</body>
</html>