<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
	<meta charset="utf-8">
	<title>La Cuisine</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="stylesheet.css">
	<link href='https://fonts.googleapis.com/css?family=Notable' rel='stylesheet'>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css"> 
	<script src="https://kit.fontawesome.com/a076d05399.js"></script>
<style>
	*{box-sizing: border-box;}

	body, html {
		font-family: Arial, Helvetica, sans-serif;
		height: 100%;
		margin: 0;	
	}

.navbar {
  position: fixed;
  top: 0;
  right: 0;
  width: 35%;
  height: 5%;
  background-color: #d22d2d;
  overflow: none;
  display: inline-flex;
  opacity: 0.8;

}

.navbar a {
  float: right;
  padding: 2px;
  padding-right: 5px;
  color: white;
  text-decoration: none;
  text-align: center;
  font-size: 16px;
  margin: auto;
}

.navbar a:hover  {
	background-color: none;
	color: black;
}

.navbar input[type=text] {
	padding-left: 4px;
	margin: 4px;
	font-size: 16px;
	border: none;
	border-radius: 4px;
}

.navbar .search-container button {
	float:right;
	padding: none;
	margin-top: 4px;
	background: none;
	font-size: 18px;
	border: none;
	cursor: pointer;
	color: white;
}

.navbar .search-container button:hover {
	background-color: none;
	color: black;
}

.dropdown {
	float: right;
	overflow: hidden;
}

.dropdown .dropbtn {
	font-size: 16px;
	border: none;
  	outline: none;
  	color: white;
  	padding: 8px;
  	padding-right: 10px;
  	background-color: inherit;
  	color: white;
  	font-family: inherit;
  	margin: auto;
}

.dropdown:hover .dropbtn {
	background-color: black;
}

.dropdown-content {
	display: none;
  	position: absolute;
  	background-color: #f9f9f9;
  	min-width: 100px;
  	box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  	z-index: 1;
}

.dropdown-content a {
	float: none;
  	color: black;
 	padding: 10px;
  	text-decoration: none;
  	display: block;
  	text-align: center;
}

.dropdown-content a:hover {
	background-color: #d22d2d;
}

.dropdown:hover .dropdown-content {
	display: block;
}

.bg-image{
	height: 100%;
	background-position: center;
	background-size: cover;
	background-repeat: no-repeat;
}
.img1 { background-image: url("BG3.jpg"); }
.img2 { background-image: url("BG4.jpg"); }
.img3 { background-image: url("BG2.jpg"); }
.img4 { background-image: url("BG5.jpg"); }

.sidenav {
	height: 100%;
	width: 350px;
	position: fixed;
	z-index: 1;
	top: 0;
	left: 0;
	background-color: #ff3333;
	background-image: url("SBG.jpg");
	overflow-x: hidden;
	padding-top: block;
	border:2px;
}

.sidenav a {
	padding: 6px, 8px, 6px, 16px;
	text-decoration: none;
	font-family: sans-serif;
	font-size: 28px;
	margin: 15px;
	color: white;
	text-align: center;
	display: block;
}

.sidenav a:hover {
	color: black;
}

.main {
	margin-left: 160px;
	font-size: 28px;
	padding: 0px 10px;
}

@media screen and (max-height: 450px) {
	.sidenav {padding-top: 15px;}
	.sidenav a {font-size: 18px;}
}

.header a.logo {
	font-family: 'Notable';
	font-size: 40px;
	color: black;
	letter-spacing: 1px;
}

h1 {
	text-align: center;
	font-family: sans-serif;
	font-size: 12px;
	color: white;
	margin-top: 25px;
	word-spacing: 4px;

}
h2 {
	text-align: center;
	font-family: sans-serif;
	font-size: 12px;
	color: white;
	margin-bottom: 5px;
	word-spacing: 4px;
}

h3 {
	text-align: center;
	font-family: sans-serif;
	font-size: 12px;
	color: white;
	margin-bottom: 25px;
}

.sidepanel {
  	width: 0;
  	display: hidden;
  	position: absolute;
  	z-index: 1;
  	height: 300px;
  	bottom: 0;
  	left: 0;
  	background-color: #111;
  	overflow-x: hidden;
  	transition: 0.5s;
  	padding-top: 60px;
}

.sidepanel a {
	width: auto;
  	padding: 8px 8px 8px 32px;
  	padding-left: 10px;
  	text-align: left;
  	font-size: 18px;
  	color: #818181;
  	display: block;
  	transition: 0.3s;
}

.sidepanel a:hover {
  	color: #f1f1f1;
}

.sidepanel .closebtn {
 	position: absolute;
 	top: 0;
  	right: 30px;
  	font-size: 32px;
}

.openbtn {
  font-size: 28px;
  position: center;
  cursor: pointer;
  background-color: inherit;
  color: white;
  padding: 4px 85px;
  margin: center;
  border: none;

}

.openbtn:hover {
  background-color:none;
  color: black;
}

</style>
</head>
<body>

	<div class="navbar">

	<a class="search-container" href="#">
		<form action="/action_page.php">
      		<input type="text" placeholder="Search.." name="search">
      		<button type="submit"><i class="fa fa-search"></i></button>
    	</form>
    </a>

   		<a href="payment.php"><i class="fa fa-shopping-cart"></i> Cart</a>

   		<div class="dropdown">
   			<button class="dropbtn"><i class="fa fa-fw fa-user"></i> Login</a>
   			</button>
   			<div class="dropdown-content">
   				<a href="login.php">Sign Up</a>
   			</div>
   		</div>
    </div>


	<div class="bg-image img4"></div>
	<div class="bg-image img3"></div>
	<div class="bg-image img2"></div>
	<div class="bg-image img1"></div>
	
	<div class="sidenav">

		<div class="header">
			<a href="#index.php" class="logo">LA CUISINE</a>
			<h1>25 Blok 3, Jalan Plumbum 7/AC</h1>
			<h2>Seksyen 7, Shah Alam, Selangor,40000</h2>
			<h3>(06+)011-2512020</h3>
	<ul>
		<li><a href="Reservations.php">RESERVATIONS</a></li>
		<li><a href="store.php">MENUS AND ORDER</a></li>
		<li><a href="trackandtrace.php">TRACK AND TRACE</a></li>
		<li><a href="registration.php">JOIN US</a></li>
		<li><button class="openbtn" onclick="openNav()">CONTACT US</button></li>
			<div id="mySidepanel" class="sidepanel">
			<a href="javascript:void(0)" class="closebtn" onclick="closeNav()">x</a>
			<a href="https://gmail.com"><i class="fas fa-envelope"></i> Email</a>
			<a href="#"><i class="fa fa-phone"></i> (06+)011-2512020</a>
			<a href="#"><i class="fa fa-instagram"></i> Instagram</a>
			<a href="#"><i class="fa fa-facebook"></i> Facebook</a>
			</div>
	</ul>
		</div>
<script>
/* When the user clicks on the button, 
toggle between hiding and showing the dropdown content */
function myFunction() {
  document.getElementById("myDropdown").classList.toggle("show");
}

// Close the dropdown if the user clicks outside of it
window.onclick = function(event) {
  if (!event.target.matches('.dropbtn')) {
    var dropdowns = document.getElementsByClassName("dropdown-content");
    var i;
    for (i = 0; i < dropdowns.length; i++) {
      var openDropdown = dropdowns[i];
      if (openDropdown.classList.contains('show')) {
        openDropdown.classList.remove('show');
      }
    }
  }
}

function openNav() {
  document.getElementById("mySidepanel").style.width = "250px";
}

function closeNav() {
  document.getElementById("mySidepanel").style.width = "0";
}

</script>

</body>
</html>