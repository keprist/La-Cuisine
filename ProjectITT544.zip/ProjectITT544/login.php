<?php
require_once('config.php');
?>

<!DOCTYPE html>
<html>
<head>
	<title>User sign in | PHP</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">

	<style>
         body {
            padding-top: 40px;
            padding-bottom: 40px;
            background-image: url("BG4.jpg");
            background-position: cover;
         }
    </style>

</head>
<body>

<div>
	<?php
	if (isset($_POST['create'])) {
		$Name 			= $_POST['Name'];
		$password 		= $_POST['password'];

		$sql = "INSERT INTO login (Name, password ) VALUES (?,?)";
		$stmtinsert = $db->prepare($sql);
		$result = $stmtinsert-> execute ([$Name, $Address, $Email, $phonenumber, $password]);

		if ($result) {
			echo 'Saved.';
		}
		else{
			echo 'There were errors while saving the data.';
		}
		
	}
	?>
</div>

	<div>
		
		<form action="login.php" method="post">
			<div class="container">
				<div align = "center">
					<div style = padding:3px;"><b></div>
				<div class="row">
					<div class="col-sm-3">

					<h1>Sign in</h1>
					<p>Fill up the form with registration value.</p>
					<hr class="mb-3">

					<label for="Name"><b>Name</b></label>
					<input class="form-control" type="text" id="Name" name="Name" required><br><br>

					<label for="password"><b>Password</b></label>
					<input class="form-control" type="password" id="password" name="password" required><br><br>

					<div class="form-group">
						<a href="index.php" class="btn btn-primary" type="submit" value="Login">Login</a>
					</div>
					<p>Don't have an account? <a href="registration.php">Register Now</a></p>

					<div>
					<a href="new.php" style=" margin-right: 0px; font-size: 13px; font-family: Tahoma, Geneva, sans-serif;">Reset password</a>

					</div>


					</div>
				</div>
				</div>
			</div>
		</form>

	</div>
</body>
</html>