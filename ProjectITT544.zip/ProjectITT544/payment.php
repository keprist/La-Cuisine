<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Payment Checkout</title>
	<link rel="stylesheet" href="style.css">
	<link rel="stylesheet" href="http://use.fontawesome.com/releases/v5.5.0/css/all.css">
</head>
<body>

<div class="wrapper">
	<div class="payment">

		<h2>Payment Gateway</h2>
		
		<div class="form">
			<div class="card space icon-relative">
				<label class="label">Card Holder:</label>
				<input type="text" class="input" name="card_holder" placeholder="La Cuisine">
				<i class="fas fa-user"></i>
			</div>
			<div class="card space icon-relative">
				<label class="label">Card Number:</label>
				<input type="text" class="input" name="card_number" placeholder="Card Number" data-mask="0000 0000 0000 0000">
				<i class="far fa-credit-card"></i>
			</div>
			<div class="card-grp space">
				<div class="card-item icon-relative">
					<label class="label">Expiry Date:</label>
					<input type="text" class="input" name="card_number" placeholder="00 / 00" data-mask="00 / 00">
					<i class="far fa-calendar-alt"></i>
				</div>
				<div class="card-item icon-relative">
					<label class="label">CVC:</label>
					<input type="text" class="input" name="cvc" placeholder="000" data-mask="000">
					<i class="fas fa-lock"></i>
				</div>
			</div>

			<div class="btn"><a href="SuccessPay.php">Pay</div>
		</div>
	</div>
</div>

<script src="http://code.jquery.com/jquery-3.3.1.min.js"></script>
<script src="http://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.15/jquery.mask.min.js"></script>
</body>
</html>