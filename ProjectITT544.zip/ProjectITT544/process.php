<?php

echo "Hello from process";
