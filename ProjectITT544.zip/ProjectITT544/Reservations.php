﻿<html>
       <head><title>Reservations La Cuisine/title>
<!DOCTYPE html>
<html lang="en">
<meta charset="UTF-8">
<title>Booking</title>
<link rel="stylesheet" href="css/style.txt" type="text/css>
<!-- Font -->
<link href="https://fonts.googleapis.com/css?family=Raleway:400,600,700,900" rel="stylesheet">

</head>
<style>
  body{
    padding-top: 40px;
    padding-bottom: 40px;
    background-image:url("BG.jpg");
    background-position: cover;
  }
</style>
<body>

   <div class="container">
       <div class="container-time">
               <h2 class="heading">Time Open</h2>
               <h3 class="heading-days">Monday-Friday</h3>
               <p>7am - 11am (breakfast)</p>
               <p>11am - 10 pm (lunch/dinner)</p>
               
               <h3 class="heading-days">Saturday and Sunday</h3>
               <p>9am - 11am (breakfast)</p>
               <p>11am - 10 pm (lunch/dinner)</p>

               <hr>
    
               <h4 class="heading-phone"> Call Us : (06+)011-2512020</h4>
       
        </div>

        <div>
<form action="#">
<h2>Reservation Online</h2>
<div>
<p>Your Name</p>
<input type="text" placeholder="Your Name">
</div>
<div>
<p>Your email</p>
<input type="email" placeholder="Your email">
</div>
<div>
<p>Date</p>
<input type="date">
</div>
<div>
<p>Time</p>
<input type="time">
</div>
<div>
<p>How many people?</p>
<select name="select" id="#">
<option value="1">1 person</option>
<option value="2">2 persons</option>
<option value="3">3 persosn</option>
<option value="4">4 persons</option>
<option value="5">5 persons</option>
<option value="5+">5+ persons</option>
</select>
</div>
<button>
  <a  href="index.php"  class="btn btn-primary">Submit</a>
</button>
</form>
</div>
</div>
</body>
</html>

       