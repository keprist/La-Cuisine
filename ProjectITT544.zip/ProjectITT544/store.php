<!DOCTYPE html>
<html>
	<head>
		<title>LA CUISINE</title>
        	<link rel="stylesheet" href="store.css"/>
        	<script src="store.js" async></script>
        </head>

        <style>
             body{
                padding-top: 40px;
                padding-bottom: 40px;
                background-image:url("a.jpg");
                background-position: cover;
             }
        </style>

        <body>
		
        	<section class="container content-section">
			
            		<h2 class="section-header">FOODS</h2>
            		<div class="shop-items">
                		<div class="shop-item">
                    			<span class="shop-item-title">French Onion Soup</span>
					<image class="shop-item-image" src="French-onion-soup.jpg" width="200" height="100">
					<div class="shop-item-details">
						<span class="shop-item-price">$7</span>
                        			<button class="btn btn-primary shop-item-button" type="button">ADD TO CART</button>
                    			</div>
                		</div>
                		<div class="shop-item">
					<span class="shop-item-title">Flamiche</span>
					<image class="shop-item-image" src="Flamiche.jpg"
					width="200" height="100">
					<div class="shop-item-details">
						<span class="shop-item-price">$5</span>
                        			<button class="btn btn-primary shop-item-button"type="button">ADD TO CART</button>
                    			</div>
               			 </div>
                		<div class="shop-item">
					<span class="shop-item-title">Cassoulet</span>
					<image class="shop-item-image" src="Cassoulet.jpg"
					width="200" height="100">
					<div class="shop-item-details">
						<span class="shop-item-price">$10</span>
                        			<button class="btn btn-primary shop-item-button" type="button">ADD TO CART</button>
                    			</div>
                		</div>
				<div class="shop-item">
                			<span class="shop-item-title">Ratatouille</span>
					<image class="shop-item-image" src="Ratatouille.jpg"
					width="200" height="100">
					<div class="shop-item-details">
						<span class="shop-item-price">$8</span>
                        			<button class="btn btn-primary shop-item-button" type="button">ADD TO CART</button>
                   			</div>
                		</div>
				<div class="shop-item">
					<span class="shop-item-title">Tarte Tatin</span>
					<image class="shop-item-image" src="Tarte-tatin.jpg"
					width="200" height="100">
					<div class="shop-item-details">
						<span class="shop-item-price">$5</span>
                        			<button class="btn btn-primary shop-item-button" type="button">ADD TO CART</button>
                   			</div>
                		</div>
            		</div>
        	</section>
        	<section class="container content-section">
            		<h2 class="section-header">DRINK</h2>
           	 	<div class="shop-items">
                		<div class="shop-item">
					<span class="shop-item-title">Hurricane</span>
					<image class="shop-item-image" src="Hurricane.png"
					width="200" height="100">
					<div class="shop-item-details">
						<span class="shop-item-price">$3</span>
                        			<button class="btn btn-primary shop-item-button" type="button">ADD TO CART</button>
                    			</div>
                		</div>
                		<div class="shop-item">
					<span class="shop-item-title">Flamingo Tango</span>
					<image class="shop-item-image" src="Flamingo-Tango.jpg"
					width="200" height="100">
					<div class="shop-item-details">
						<span class="shop-item-price">$3</span>
                        			<button class="btn btn-primary shop-item-button" type="button">ADD TO CART</button>
                    			</div>
                		</div>
                		<div class="shop-item">
					<span class="shop-item-title">Bahama Mama</span>
					<image class="shop-item-image" src="Bahama-mama.jpg"
					width="200" height="100">
					<div class="shop-item-details">
						<span class="shop-item-price">$3</span>
                        			<button class="btn btn-primary shop-item-button" type="button">ADD TO CART</button>
                    			</div>
                		</div>
                		<div class="shop-item">
					<span class="shop-item-title">Cherry Limeade</span>
					<image class="shop-item-image" src="Cherry-Limeade.jpg"
					width="200" height="100">
					<div class="shop-item-details">
						<span class="shop-item-price">$3</span>
                        			<button class="btn btn-primary shop-item-button" type="button">ADD TO CART</button>
                    			</div>
                		</div>
                		<div class="shop-item">
                    			<span class="shop-item-title">Caribalou</span>
					<image class="shop-item-image" src="Caribalou.jpg"
					width="200" height="100">
					<div class="shop-item-details">
						<span class="shop-item-price">$3</span>
                        			<button class="btn btn-primary shop-item-button" type="button">ADD TO CART</button>
                    			</div>
                		</div>
            		</div>
        	</section>
        	<section class="container content-section">
            		<h2 class="section-header">CART</h2>
            		<div class="cart-row">
                		<span class="cart-item cart-header cart-column">ITEM</span>
                		<span class="cart-price cart-header cart-column">PRICE</span>
                		<span class="cart-quantity cart-header cart-column">QUANTITY</span>
            		</div>
            		<div class="cart-items">
            		</div>
            		<div class="cart-total">
                		<strong class="cart-total-title">Total</strong>
                		<span class="cart-total-price">$0</span>
            		</div>
            		<a href="payment.php"><button class="btn btn-primary btn-purchase" type="button">PURCHASE</button>
        	</section>
    	</body>
</html>